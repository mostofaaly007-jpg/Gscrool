package com.gscrool.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Bg = Color(0xFF05060A)
private val Card = Color(0xFF10131B)
private val Cyan = Color(0xFF12D8FF)
private val Purple = Color(0xFF714CFF)

data class Post(val user: String, val title: String, val image: String, val likes: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GscroolApp() }
    }
}

@Composable
fun GscroolApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var currentUser by remember { mutableStateOf(auth.currentUser) }
    if (currentUser == null) {
        AuthScreen(auth) { currentUser = auth.currentUser }
        return
    }
    var selected by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Card)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = { BottomBar(selected) { selected = it } }
        ) { padding ->
            when (selected) {
                0 -> Home(Modifier.padding(padding))
                1 -> Search(Modifier.padding(padding))
                2 -> Create(Modifier.padding(padding))
                3 -> Reels(Modifier.padding(padding))
                else -> Profile(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun AuthScreen(auth: FirebaseAuth, onAuthenticated: () -> Unit) {
    var signUp by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.SportsEsports, null, tint = Cyan, modifier = Modifier.size(72.dp))
        Text("Gscrool", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
        Text(if (signUp) "Create your gaming account" else "Welcome back, gamer",
            color = Color.LightGray, fontSize = 16.sp)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
        if (signUp) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(confirm, { confirm = it }, label = { Text("Confirm password") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
        }
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp)); Text(error, color = Color(0xFFFF7B7B))
        }
        Spacer(Modifier.height(20.dp))
        Button(
            enabled = !busy,
            onClick = {
                error = ""
                if (email.isBlank() || password.length < 6) {
                    error = "Enter a valid email and a password of at least 6 characters."
                } else if (signUp && password != confirm) {
                    error = "Passwords do not match."
                } else {
                    busy = true
                    val task = if (signUp) auth.createUserWithEmailAndPassword(email.trim(), password)
                               else auth.signInWithEmailAndPassword(email.trim(), password)
                    task.addOnCompleteListener { result ->
                        busy = false
                        if (result.isSuccessful) onAuthenticated()
                        else error = result.exception?.localizedMessage ?: "Authentication failed."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan)
        ) { Text(if (busy) "Please wait…" else if (signUp) "Create account" else "Sign in", color = Bg) }
        TextButton(onClick = { signUp = !signUp; error = "" }) {
            Text(if (signUp) "Already have an account? Sign in" else "New to Gscrool? Create an account", color = Cyan)
        }
    }
}

@Composable
fun TopBar() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.SportsEsports, null, tint = Cyan, modifier = Modifier.size(30.dp))
        Spacer(Modifier.width(8.dp))
        Text("Gscrool", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold,
            color = Color.White)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.NotificationsNone, null, tint = Color.White)
        Spacer(Modifier.width(18.dp))
        Icon(Icons.Default.Send, null, tint = Color.White)
    }
}

@Composable
fun Home(modifier: Modifier = Modifier) {
    val posts = listOf(
        Post("ShadowX", "Ranked grind 🔥", "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=900", 1842),
        Post("NovaPlay", "New setup reveal 🎮", "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=900", 921),
        Post("Raptor", "Victory royale!", "https://images.unsplash.com/photo-1605901309584-818e25960a8f?w=900", 3210)
    )
    LazyColumn(modifier.fillMaxSize()) {
        item { TopBar(); Stories() }
        items(posts) { PostCard(it) }
    }
}

@Composable
fun Stories() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
        listOf("You", "ShadowX", "Nova", "Raptor", "Miko").forEachIndexed { i, name ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
                Box(Modifier.size(58.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Cyan, Purple))),
                    contentAlignment = Alignment.Center) {
                    Text(if (i == 0) "+" else "G", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
                Text(name, color = Color.LightGray, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun PostCard(post: Post) {
    var liked by remember { mutableStateOf(false) }
    Column(Modifier.padding(bottom = 18.dp).background(Card)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Cyan), contentAlignment = Alignment.Center) {
                Text("G", color = Bg, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Text(post.user, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.MoreVert, null, tint = Color.White)
        }
        AsyncImage(post.image, null, Modifier.fillMaxWidth().height(300.dp), contentScale = ContentScale.Crop)
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null,
                tint = if (liked) Color.Red else Color.White,
                modifier = Modifier.size(28.dp).clickable { liked = !liked })
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Default.ModeComment, null, tint = Color.White, modifier = Modifier.size(27.dp))
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Default.Send, null, tint = Color.White, modifier = Modifier.size(27.dp))
        }
        Text("${if (liked) post.likes + 1 else post.likes} likes", color = Color.White,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
        Text(post.title, color = Color.White, modifier = Modifier.padding(12.dp))
    }
}

@Composable
fun Search(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Search", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = "", onValueChange = {}, placeholder = { Text("Search gamers, games, creators") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(20.dp))
        Text("Trending gaming", color = Cyan, fontWeight = FontWeight.Bold)
        listOf("BGMI", "Free Fire", "Minecraft", "Valorant", "GTA V").forEach {
            Text("#$it", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(vertical = 10.dp))
        }
    }
}

@Composable
fun Create(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Create", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(40.dp))
        Icon(Icons.Default.AddCircleOutline, null, tint = Cyan, modifier = Modifier.size(100.dp))
        Spacer(Modifier.height(20.dp))
        Text("Share your gaming moment", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(20.dp))
        Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
            Text("Choose photo or video", color = Bg)
        }
    }
}

@Composable
fun Reels(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Text("🎮\nGaming Reels", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Profile(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(84.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Cyan, Purple))),
                contentAlignment = Alignment.Center) {
                Text("G", color = Bg, fontSize = 32.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(18.dp))
            Column {
                Text("Gscrool Gamer", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("@gscrool", color = Color.Gray)
            }
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("Posts", "12"); Stat("Followers", "2.4K"); Stat("Following", "180")
        }
        Spacer(Modifier.height(24.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Edit profile") }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = Color.Gray)
    }
}

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF090B11)) {
        val items = listOf(
            Icons.Default.Home to "Home",
            Icons.Default.Search to "Search",
            Icons.Default.AddBox to "Create",
            Icons.Default.PlayCircle to "Reels",
            Icons.Default.Person to "Profile"
        )
        items.forEachIndexed { i, pair ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = { Icon(pair.first, pair.second) },
                label = { Text(pair.second) }
            )
        }
    }
}
